#!/bin/bash
/usr/sbin/ntpdate -u time.google.com

LOG="/var/log/certbot-renew.log"
DATE=$(date "+%Y-%m-%d %H:%M:%S")

echo "[$DATE] Starting certbot renew (nginx)" >> $LOG

# Renew certificates
/usr/bin/certbot renew \
  --quiet \
  --no-self-upgrade >> $LOG 2>&1

/usr/sbin/nginx -t && /usr/sbin/nginx -s reload

echo "[$DATE] Done" >> $LOG
