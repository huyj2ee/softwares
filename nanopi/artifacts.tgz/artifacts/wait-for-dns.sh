#!/bin/sh

HOST="time.google.com"
TIMEOUT=60
INTERVAL=2

echo "Waiting for DNS resolution..."

i=0
while [ $i -lt $TIMEOUT ]; do
  if getent hosts "$HOST" > /dev/null 2>&1; then
    echo "DNS OK"
    exit 0
  fi
  sleep $INTERVAL
  i=$((i + INTERVAL))
done

echo "DNS failed"
exit 1
